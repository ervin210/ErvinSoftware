// Google Pay Integration Example
const googlePayClient = new google.payments.api.PaymentsClient({ environment: 'TEST' });

const paymentDataRequest = {
  apiVersion: 2,
  apiVersionMinor: 0,
  allowedPaymentMethods: [{
    type: 'CARD',
    parameters: {
      allowedAuthMethods: ['PAN_ONLY', 'CRYPTOGRAM_3DS'],
      allowedCardNetworks: ['MASTERCARD', 'VISA']
    },
    tokenizationSpecification: {
      type: 'PAYMENT_GATEWAY',
      parameters: {
        'gateway': 'example',
        'gatewayMerchantId': 'exampleMerchantId'
      }
    }
  }],
  transactionInfo: {
    totalPriceStatus: 'FINAL',
    totalPrice: '10.00',
    currencyCode: 'USD'
  }
};

googlePayClient.loadPaymentData(paymentDataRequest)
  .then(function(paymentData) {
    console.log('Google Pay successful', paymentData);
  })
  .catch(function(error) {
    console.error('Error during Google Pay transaction', error);
  });
    