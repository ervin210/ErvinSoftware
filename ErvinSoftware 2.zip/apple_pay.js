// Apple Pay Integration Example
const paymentRequest = {
  countryCode: 'US',
  currencyCode: 'USD',
  total: {
    label: 'Ervin Software',
    amount: '10.00'
  },
  supportedNetworks: ['visa', 'masterCard'],
  merchantCapabilities: ['supports3DS']
};

const applePaySession = new ApplePaySession(3, paymentRequest);

applePaySession.onvalidatemerchant = function(event) {
  validateMerchant(event.validationURL).then(function(merchantSession) {
    applePaySession.completeMerchantValidation(merchantSession);
  });
};

document.getElementById('apple-pay-button').addEventListener('click', function() {
  applePaySession.begin();
});
    